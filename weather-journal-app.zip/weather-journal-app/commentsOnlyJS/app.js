// Personal API Key for OpenWeatherMap API
let baseURL = 'http://api.openweathermap.org/data/2.5/weather?zip='
let apiKey = '&apiid=7b2e2d026df63966c2f09976b5680ebe';

// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click', performAction);
/* Function called by event listener */
function performAction(e){
    
}
/* Function to GET Web API Data*/

/* Function to POST data */


/* Function to GET Project Data */
